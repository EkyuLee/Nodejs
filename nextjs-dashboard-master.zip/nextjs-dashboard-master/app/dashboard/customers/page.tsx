import { Metadata } from 'next';

export const metadata : Metadata = {
    title : 'customers',
}

export default function page(){
    return <p>this one is customer page</p>
}